export const ADDED_BY_TYPES = {
  admin: "admin",
  self: "self",
};
