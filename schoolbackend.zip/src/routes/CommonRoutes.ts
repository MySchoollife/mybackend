import axios from "axios";
import { Router } from "express";
import { param } from "express-validator";
import * as mongoose from "mongoose";

import UploadFiles from "../Middlewares/FileUploadMiddleware";

import { CommonController } from "../controllers/CommonController";
import _RS from "../helpers/ResponseHelper";

const collationOptions = {
  locale: "en",
  strength: 2,
};

class CommonRoutes {
  public router: Router;

  constructor() {
    this.router = Router();
    this.post();
    this.get();
  }

  public post() {
    this.router.post(
      "/image-upload",
      UploadFiles.upload,
      CommonController.uploadImage
    );
    this.router.post(
      "/file-upload",
      UploadFiles.upload,
      CommonController.uploadFile
    );
  }

  public get() {}
}

export default new CommonRoutes().router;
